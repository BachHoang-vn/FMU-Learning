#!/bin/bash

# Try DISPLAY=:0 first
export DISPLAY=:0
export XAUTHORITY=/run/user/124/gdm/Xauthority

# Check if X server is accessible
if xdpyinfo >/dev/null 2>&1; then
    echo "Using DISPLAY=:0"
else
    echo "DISPLAY=:0 failed, trying DISPLAY=:1"
    export DISPLAY=:1
    export XAUTHORITY=/run/user/1001/gdm/Xauthority
    if ! xdpyinfo >/dev/null 2>&1; then
        echo "Error: No X server available on :0 or :1"
        exit 1
    fi
fi

# Activate the virtual environment
source cockpit-env/bin/activate || {
    echo "Error: Failed to activate virtual environment"
    exit 1
}

# Launch the web server in the background
python server.py > server.log 2>&1 &
SERVER_PID=$!

# Wait for the server to start
sleep 3

# Display server status
echo "Server.py output (last 10 lines):"
tail -n 10 server.log

# Check if the server is running
if ! curl --output /dev/null --silent --fail http://localhost:5000; then
    echo "Error: Web server not running on http://localhost:5000"
    kill $SERVER_PID
    exit 1
fi

# Open the web app in Firefox
firefox http://localhost:5000 || {
    echo "Error: Failed to open Firefox"
    kill $SERVER_PID
    exit 1
}

# Keep the script running
wait $SERVER_PID
