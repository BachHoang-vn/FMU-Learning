// ============================================================================================================== //
// Constant Definition
// ============================================================================================================== //
let isAirbagOffMessageShowing = false;

const passengerAirbagState = {
    NoConfirm: 0,
    Enable: 1,
    Disable: 2,
    Init: 3,
}
const warningLevel = {
    NoWarning: "",
    FirstLevel: `WARNING!<br>
Child detected, Please confirm!`,
    SecondLevel: `WARNING!<br>
Child detected, Please confirm!`,
    AirbagOffMessage: "Passenger Airbag is now OFF.",
    AirbagOnMessage: "Passenger Airbag is now ON."
}
const passengerAirbagLamp = {
    Enable: false,
    Disable: true,
}

const PassengerAirbagConfirm_API = "Vehicle.Cabin.Seat.Row1.PassengerSide.Height";      // datatype: uint16
const WarningMessage_API = "Vehicle.Cabin.Seat.Row1.PassengerSide.Position";             // datatype: uint16
const Speed_API = "Vehicle.Speed";                                             // datatype: float
const AirbagLamp_API = "Vehicle.Cabin.Seat.Row1.PassengerSide.Airbag.IsDeployed";   // datatype: boolean

// ============================================================================================================== //
// Setting Up Behavior
// ============================================================================================================== //

// Set initial behavior on page load
window.addEventListener("load", function () {
    print_log("Set initial behavior on page load:");
    sendValue(passengerAirbagState.NoConfirm);
});

window.onload = function() {
    // Call only after everything is loaded
    // Declare Polling: Call getValue() every 0.6 seconds
    setInterval(updateAllValue, 600);
};

// Function to update All Value
function updateAllValue() {
    leftPane_UpdateValue();
    middlePane_UpdateValue();
    rightPane_UpdateValue();
}

const delay = (delayInms) => {
  return new Promise(resolve => setTimeout(resolve, delayInms));
};
// ============================================================================================================== //
// Related to Left Pane
// ============================================================================================================== //

let blinkInterval;
let audio = new Audio('effect_notify-84408.mp3');
async function leftPane_UpdateValue() {
    if (isAirbagOffMessageShowing) return;
    let warningValue = await getApiValue(WarningMessage_API);
    const buttonContainer = document.querySelectorAll(".LeftPane-GridItem")[3];
    // const warningIconContainer = document.getElementById("warningIconContainer");
    // const warningTextContainer = document.getElementById("warningTextContainer");


    if (warningValue === 1 || warningValue === 2) {
        buttonContainer.style.display = "flex";
    } else {
        buttonContainer.style.display = "none";
    }
    console.log(`warning value is ${warningValue}`);
    let warningMessage = "";
    let blinkSpeed = 0; // Default: No blinking
    switch (warningValue) {
        case 1:
            warningMessage = warningLevel.FirstLevel;
            showWarningPopup();
            blinkSpeed = 350; // Blink every 0.35s
            audio.playbackRate = 1/0.35
            break;
        case 2:
            warningMessage = warningLevel.SecondLevel;
            showWarningPopup();
            blinkSpeed = 170; // Blink every 0.15s
            audio.playbackRate = 1/0.17
            break;
        case 0:
        default:
            warningMessage = warningLevel.NoWarning;
            hideWarningPopup();
            blinkSpeed = 0;
            break;
    }
    // Update Baby Warning Message
    const warningElement = document.querySelector(".HighlightText");
    warningElement.innerHTML = warningMessage;
    warningElement.classList.add("warning-message");

    // Clear previous blinking interval
    if (blinkInterval) {
        clearInterval(blinkInterval);
        warningElement.style.visibility = "visible"; // Ensure it's visible when blinking stops
    }

    // Apply blinking effect and play audio
    if (blinkSpeed > 0) {
        audio.play(); // Start audio

        blinkInterval = setInterval(() => {
            warningElement.style.visibility = (warningElement.style.visibility === "hidden") ? "visible" : "hidden";

            // Restart audio if it's finished
            if (audio.ended) {
                audio.currentTime = 0; // Reset to the beginning
                audio.play();
            }
        }, blinkSpeed);
    } else {
        audio.pause();
        audio.currentTime = 0; // Reset audio when there's no warning
    }

    print_log("Warning Value: " + warningValue);
}

const leftPane = document.querySelector(".LeftPane");

// Function to hide Warning Popup
function hideWarningPopup() {
    leftPane.classList.add("hide-content");
    leftPane.classList.remove("show-content");
}

// Function to show Warning Popup
function showWarningPopup() {
    leftPane.classList.remove("hide-content");
    leftPane.classList.add("show-content");
}

// Function On Enable Confirm
async function OnEnableConfirm() {
    sendValue(passengerAirbagState.Disable);
    isAirbagOffMessageShowing = true; // Prevent further updates    
    delay(1000);
    //clear old warning message
    if (blinkInterval) {
        clearInterval(blinkInterval);
        // Ensure it's visible when blinking stops
    }
    audio.pause();
    audio.currentTime = 0;
    // Hide popup immediately
    //hideWarningPopup();

    // Hide warning text
    const warningElement = document.querySelector(".LeftPane .HighlightText");
    warningElement.innerHTML = ""; // Clear message
    warningElement.style.visibility = "hidden";

    // Hide warning text and icon by adding hide class
    // Hide both the icon and text when "Yes" is clicked
    




    let lampValue = false;
    let maxRetry = 30;
    do {
        // await delay(200);
        lampValue = await getApiValue(AirbagLamp_API);
        console.log("Waiting for lamp OFF, current value:", lampValue);
        if (lampValue === passengerAirbagLamp.Disable){
            maxRetry--;
            hideWarningPopup();
        }
        else {
            maxRetry = 30;
        }
        
    } while (maxRetry !== 0);

    
    if (lampValue === passengerAirbagLamp.Disable){
        hideWarningPopup();

        document.getElementById("ackMessageContainer").style.display = "none";
        // await delay(500);
        // isAirbagOffMessageShowing = true;
        if (blinkInterval) {
            clearInterval(blinkInterval);
            // Ensure it's visible when blinking stops
        }
        audio.pause();
        audio.currentTime = 0;

        //show new message
        const messageBox = document.getElementById("airbagOffMessageBox");
        messageBox.style.display = "block";
        const warningIconContainer = document.getElementById("warningIconContainer");
        const warningTextContainer = document.getElementById("warningTextContainer");

        if (warningIconContainer) {
            warningIconContainer.classList.add("hide");
        }

        if (warningTextContainer) {
            warningTextContainer.classList.add("hide");
        }

        // yes/no OFF
        const buttonContainer = document.querySelectorAll(".LeftPane-GridItem")[3];
        buttonContainer.style.display = "none";
        showWarningPopup();
        
        
        // warningElement.style.visibility = "visible";
        await delay(3000);  // 3s display
        messageBox.style.display = "none";

        hideWarningPopup(); // hide it
        hideWarningPopup(); // hide it
        warningElement.innerHTML = ""; //clear content
        isAirbagOffMessageShowing = false;
    }
    

    // Waiting For The Backend Process is completed
    await new Promise(resolve => setTimeout(resolve, 1000)); // 500ms delay
    // let warningValue = getApiValue(WarningMessage_API)
    // Reset to No Confirm
    sendValue(passengerAirbagState.Init);
    document.getElementById("ackMessageContainer").style.display = "flex";
    if (warningIconContainer) {
        warningIconContainer.classList.remove("hide");
    }
    
    if (warningTextContainer) {
        warningTextContainer.classList.remove("hide");
    }
    leftPane_UpdateValue();
}

// Function On Disable Confirm
async function OnDisableConfirm() {
    sendValue(passengerAirbagState.Enable);
    isAirbagOffMessageShowing = true; // Prevent further updates
    
    //clear old warning message
    if (blinkInterval) {
        clearInterval(blinkInterval);
        // Ensure it's visible when blinking stops
    }
    audio.pause();
    audio.currentTime = 0;
    // Hide popup immediately
    hideWarningPopup();

    // Hide warning text
    const warningElement = document.querySelector(".LeftPane .HighlightText");
    warningElement.innerHTML = ""; // Clear message
    warningElement.style.visibility = "hidden";

    // Hide warning text and icon by adding hide class
    // Hide both the icon and text when "Yes" is clicked
    




    let lampValue = false;
    let maxRetry = 30;
    do {
        // await delay(200);
        lampValue = await getApiValue(AirbagLamp_API);
        console.log("Waiting for lamp ON, current value:", lampValue);
        if (lampValue === passengerAirbagLamp.Enable){
            maxRetry--;
            hideWarningPopup();
        }
        else {
            maxRetry = 30;
        }
        
    } while (maxRetry !== 0);

    
    if (lampValue === passengerAirbagLamp.Enable){
        hideWarningPopup();

        document.getElementById("ackMessageContainer").style.display = "none";
        // await delay(500);
        // isAirbagOffMessageShowing = true;
        if (blinkInterval) {
            clearInterval(blinkInterval);
            // Ensure it's visible when blinking stops
        }
        audio.pause();
        audio.currentTime = 0;

        //show new message
        // const messageBox = document.getElementById("airbagOffMessageBox");
        // messageBox.style.display = "block";
        const warningIconContainer = document.getElementById("warningIconContainer");
        const warningTextContainer = document.getElementById("warningTextContainer");

        if (warningIconContainer) {
            warningIconContainer.classList.add("hide");
        }

        if (warningTextContainer) {
            warningTextContainer.classList.add("hide");
        }

        // yes/no OFF
        const buttonContainer = document.querySelectorAll(".LeftPane-GridItem")[3];
        buttonContainer.style.display = "none";
        showWarningPopup();
        
        
        // warningElement.style.visibility = "visible";
        await delay(3000);  // 3s display
        // messageBox.style.display = "none";

        hideWarningPopup(); // hide it
        warningElement.innerHTML = ""; //clear content
        isAirbagOffMessageShowing = false;
    }
    

    // Waiting For The Backend Process is completed
    await new Promise(resolve => setTimeout(resolve, 1000)); // 500ms delay
    // let warningValue = getApiValue(WarningMessage_API)
    // Reset to No Confirm
    sendValue(passengerAirbagState.Init);
    document.getElementById("ackMessageContainer").style.display = "flex";
    if (warningIconContainer) {
        warningIconContainer.classList.remove("hide");
    }
    
    if (warningTextContainer) {
        warningTextContainer.classList.remove("hide");
    }
    leftPane_UpdateValue();

}


// For sending data to DataBroker
function sendValue(value) {
    setApiValue(PassengerAirbagConfirm_API, value);
    print_log("PA_Confirm Value: " + value);
}

// ============================================================================================================== //
// Related to Middle Pane
// ============================================================================================================== //

let speedValue = 0

async function middlePane_UpdateValue() {
    speedValue = await getApiValue(Speed_API);

    // Update Speed Value
    document.querySelector(".MiddlePane .SpeedValue").textContent = speedValue;

    print_log("Speed Value: " + speedValue);
}

// Function On Increasing Speed
async function OnIncreasingSpeed() {
    let value = speedValue + 1.0;
    setApiValue(Speed_API, value);
}

// Function On Increasing Speed
async function OnReducingSpeed() {
    let value = speedValue - 1.0;
    if (value < 0){
        value = 0;
    }
    setApiValue(Speed_API, value);
}


// ============================================================================================================== //
// Related to Right Pane
// ============================================================================================================== //

async function rightPane_UpdateValue() {
    try {
        // Fetch the API value
        let lampValue = await getApiValue(AirbagLamp_API);
        const lampImage = document.getElementById("lampImage");
 
        // Check if the element exists
        if (!lampImage) {
            console.error("Element 'lampImage' not found");
            return;
        }
 
        // Determine the new image source
        let newSrc;
        if (lampValue == passengerAirbagLamp.Enable) {
            newSrc = "Images/PassengerAirbagON.jpg";
        } else if (lampValue == passengerAirbagLamp.Disable) {
            newSrc = "Images/PassengerAirbagOFF.jpg";
        } else {
            newSrc = "Images/Nothing.jpg";
        }
 
        // Update the image and ensure rendering
        requestAnimationFrame(() => {
            lampImage.src = newSrc + "?" + Date.now(); // Avoid caching
            //lampImage.onload = () => console.log("Image loaded:", newSrc);
            lampImage.onload = () => {}; // Image loaded handler
            lampImage.onerror = () => console.error("Image failed to load:", newSrc);
            lampImage.offsetHeight; // Force reflow to trigger rendering
        });
 
        console.log("PA_Lamp: " + lampValue);
    } catch (error) {
        console.error("Error in rightPane_UpdateValue:", error);
    }
}
 
// Run after DOM is ready
document.addEventListener("DOMContentLoaded", async function() {
    await rightPane_UpdateValue();
});
