let apiMap = new Map()

const API_BASE = "";

const CodeState = Object.freeze({
    Developing: 0,
    Testing: 1,
    Released: 2
  });
  
const LogType = Object.freeze({
Info: 0,
Err: 1
});

const CurrentCodeState = CodeState.Released;

function print_log(arg, Type = LogType.Info, SelectedCodeState = [CodeState.Developing, CodeState.Testing]) {
if (SelectedCodeState.includes(CurrentCodeState)){
    if(Type == LogType.Info){
        console.log(arg);
    }
    else{
        console.error(arg);
    }
}
}

const setApiValue = async (apiName, value) => {
    print_log("setApiValue called");
    print_log(`API Name: ${apiName}`);
    print_log(`Value:" ${value}`);
    try {
        const res = await fetch(`${API_BASE}/set_api/${encodeURIComponent(apiName)}/${encodeURIComponent(value)}`, {
            method: "POST"
        });
        const data = await res.json();
        print_log(`[SET] ${apiName} = ${value} ${data}`);
        return data;
    } catch (err) {
        print_log(`[SET] Error setting ${apiName}: ${err}`, LogType.Err);
        return { error: err.toString() };
    }
};

const getApiValue = async (apiName) => {
    print_log("getApiValue called");
    print_log(`API Name: ${apiName}`);
    try {
        const res = await fetch(`${API_BASE}/get_api/${encodeURIComponent(apiName)}`, {
            method: "GET"
        });
        const data = await res.json();
        print_log(`[GET] ${apiName} ${data.value}`);
        return data.value;
    } catch (err) {
        print_log(`[GET] Error retrieving ${apiName}: ${err}`, LogType.Err);
        return null;
    }
};

const initHandle = () => {
    let listenForApis = []
    let VSSs = document.querySelectorAll('[vss="true"]')
    VSSs.forEach((vss) => {
        let apiName = vss.getAttribute('vss-name')
        let actionFullStr = vss.getAttribute('action')
        
        if (apiName) {
            let matchApi = apiMap.get(apiName)
            if (!matchApi) {
                matchApi = {
                    value: 0,
                    lastSetValue: 0,
                    listeners: []
                }
                apiMap.set(apiName, matchApi)
            }

            if(!actionFullStr) {
                listenForApis.push(apiName)
                matchApi.listeners.push(vss)
            } else {
                vss.addEventListener('click', () => {
                    // print_log(`[${apiName}] action ${actionFullStr} on clicked `)
                    let arrActions = actionFullStr.split("::")
                    let matchApi = apiMap.get(apiName)
                    if(arrActions.length>0 && matchApi){
                        let strValue = arrActions[1] || '0'
                        let value = 0
                        if(strValue.toLowerCase() == 'false') {
                            value = false
                        } else if(strValue.toLowerCase() == 'true') {
                            value = true
                        } else {
                            value = Number(strValue)
                        }
                        switch(arrActions[0]) {
                            case 'set':
                                // print_log(`[${apiName}] set ${value}`)
                                // matchApi.value = value
                                // matchApi.lastSetValue = new Date().getTime()
                                notifyParentApiChange(apiName, value)
                                break;
                            case 'inc':
                                break;
                            case 'dec':
                                break;
                            case 'invert':
                                break;
                        }
                    }
                })
            }
        }
        listenForApis = [...new Set(listenForApis)]
        // print_log('listenForApis')
        // print_log(listenForApis)

        if(parent && listenForApis && listenForApis.length>0) {
            parent.postMessage(JSON.stringify({
                    'cmd': 'listen-for-apis',
                    'apis': listenForApis
                }),
                    "*")
        }
    })    
    
    let interval = null
    interval = setInterval(() => {
        apiMap.forEach((api, key) => {
            if (api.listeners) {
                api.listeners.forEach(listener => {
                    let displayValueStr = listener.getAttribute('display_when_value_equal')
                    if(displayValueStr != null && displayValueStr != undefined) {
                        if(String(api.value).toLowerCase() === displayValueStr.toLowerCase()) {
                            listener.style.display='block'
                        } else {
                            listener.style.display='none'
                        }
                        return
                    }
                    if(isNaN(api.value)) {
                        listener.innerText = api.value
                    } else {
                        listener.innerText = Math.round(api.value*1000)/1000
                    }
                    
                })
            }
        })
    }, 200)
    window.addEventListener("unload", () => {
        if(onWidgetUnloaded != undefined) { onWidgetUnloaded() }
        clearInterval(interval)
    })
};

window.addEventListener('load', () => {
    print_log("syncer: on window loaded")
    try {
        if(onWidgetLoaded != undefined) {
            let options = null
            try {
                let urlParams = new URLSearchParams(window.location.search);
                options = JSON.parse(decodeURIComponent(urlParams.get('options')));
            } catch(e) { print_log(e) }
            onWidgetLoaded(options)
        }
    } catch(e) {}

    setTimeout(() => {
        initHandle()
    }, 100)
})

const applyNewVssDataFromSyncer = (vssDataIncome) => {
    if(!vssDataIncome) return
    // print_log(`vssDataIncome ${typeof(vssDataIncome)} ${vssDataIncome}`)
    let vssMap = new Map(Object.entries(vssDataIncome))
    // print_log(vssMap)
    
    apiMap.forEach((api, key) => {
        let inComeValue = vssMap.get(key)
        if(inComeValue != undefined && inComeValue != null) {
            api.value = inComeValue
        }
    })

    vssMap.forEach((incomeValue, key) => {
        if(!apiMap.get(key)) {
            apiMap.set(key, {
                value: incomeValue,
                lastSetValue: new Date(),
            })
        }
    })
    
    print_log(apiMap)
}

window.addEventListener("message", function (e) {
    if (!e.data) return
    print_log(`onMessage ${e.data}`)
    let payload = JSON.parse(e.data)
    if (payload.cmd) {
        switch (payload.cmd) {
            case 'vss-sync':
                if(!payload.vssData) return
                applyNewVssDataFromSyncer(payload.vssData)
                break;
            default:
                break;
        }
    }
})