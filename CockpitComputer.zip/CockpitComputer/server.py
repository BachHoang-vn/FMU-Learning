import asyncio
from kuksa_client.grpc import VSSClient, Datapoint
from pathlib import Path
from flask import Flask, jsonify, render_template, send_from_directory
# import logging

# Setup logging
# logging.basicConfig(level=logging.DEBUG, format="%(asctime)s - %(levelname)s - %(message)s")
# logger = logging.getLogger("KuksaServer")

app = Flask(__name__, static_folder="local_syncer")  # 'ContainerComponent' will hold container.html
script_dir = Path(__file__).resolve().parent
# Setup async bridge for gRPC
loop = asyncio.new_event_loop()
asyncio.set_event_loop(loop)
kuksaDataBroker_IP = '192.168.1.1'
kuksaDataBroker_Port = 55555

# Kuksa helpers
async def kuksa_set(api_name, value):
    try:
        #logger.debug(f"Connecting to KUKSA to set {api_name} = {value}")
        with VSSClient(kuksaDataBroker_IP, kuksaDataBroker_Port) as client:
            #logger.debug(f"Connected to KUKSA to set {api_name} = {value}")
            client.set_current_values({api_name: Datapoint(value)})
        #logger.info(f"Set {api_name} = {value}")
        return {"status": "ok", "api": api_name, "value": value}
    except Exception as e:
        #logger.error(f"Failed to set {api_name}: {e}")
        return {"error": str(e)}
    
async def kuksa_get(api_name):
    try:
        #logger.debug(f"Connecting to KUKSA to get {api_name}")
        with VSSClient(kuksaDataBroker_IP, kuksaDataBroker_Port) as client:
            #logger.debug(f"Connected to KUKSA to get {api_name}")
            val = client.get_current_values([api_name])
        value = val[api_name].value if api_name in val else "N/A"
        #logger.info(f"Got {api_name} = {value}")
        return value  # Simplified response
    except Exception as e:
        #logger.error(f"Failed to get {api_name}: {e}")
        return {"error": str(e)}

# Routes using function params
@app.route("/set_api/<apiName>/<value>", methods=["POST"])
def set_api_value(apiName, value):
    #logger.debug(f"Flask set_api_value() called with {apiName} = {value}")
    result = asyncio.run(kuksa_set(apiName, value))  # Use asyncio.run
    return jsonify(result)

@app.route("/get_api/<apiName>", methods=["GET"])
def get_api_value(apiName):
    #logger.debug(f"Flask get_api_value() called for {apiName}")
    result = asyncio.run(kuksa_get(apiName))  # Use asyncio.run
    return jsonify({"value": result})  # Wrap result in a dict

@app.route('/dashboardBox')
def dashboard_page():
    dashboard_page_path = script_dir.joinpath("dashboardBox", "CockpitDashboard2.html")
    #logger.debug(f"Flask dashboard_page() called at {dashboard_page_path}")
    return send_from_directory(script_dir.joinpath("dashboardBox").as_posix(), "CockpitDashboard2.html")

@app.route('/dashboardBox/<path:file>')
def serve_dashboard(file):
    dashboard_server_page_path = script_dir.joinpath("dashboardBox", file)
    #logger.debug(f"Flask serve_dashboard(file) called at {dashboard_server_page_path}")
    return send_from_directory(script_dir.joinpath("dashboardBox").as_posix(), file)

@app.route('/local_syncer/<path:filename>')
def serve_static(filename):
    share_server_page_path = script_dir.joinpath("local_syncer", 'syncer.js')
    #logger.debug(f"Flask local_syncer() called at {share_server_page_path}")
    return send_from_directory('local_syncer', filename)

@app.route('/')
def home():
    message = f"Server access to specific applications"
    #logger.debug(f"{message}")
    return render_template('index.html')

if __name__ == "__main__":
    #logger.info("Starting Flask server at http://localhost:5000")
    app.run(host="localhost", port=5000, debug=True)
